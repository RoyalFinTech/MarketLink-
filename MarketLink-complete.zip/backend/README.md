# MarketLink Gambia — Backend API

Production-ready REST API for the MarketLink multi-vendor marketplace platform, built for Royal FinTech Company.

## Tech Stack

| Layer | Technology |
|---|---|
| Runtime | Node.js 20 + Express 4 |
| Database | PostgreSQL 16 |
| Auth | JWT (access + refresh tokens) + bcrypt |
| File Storage | Supabase Storage |
| Email | Resend / SendGrid |
| SMS / OTP | Africa's Talking |
| Push Notifications | Firebase Cloud Messaging |
| Containerisation | Docker + Docker Compose |
| API Docs | Swagger UI (auto-generated) |

## Quick Start (Local Development)

### Prerequisites
- Node.js 20+
- Docker + Docker Compose (recommended) **or** a local PostgreSQL 16 instance

### Option A — Docker (recommended, zero config)
```bash
git clone <repo-url> marketlink-backend
cd marketlink-backend
cp .env.example .env           # review defaults; they work out of the box for Docker
docker compose up -d           # starts Postgres + API + runs migrations automatically
```

API is available at **http://localhost:4000**  
Swagger docs at **http://localhost:4000/api-docs**

### Option B — Local Node.js
```bash
git clone <repo-url> marketlink-backend
cd marketlink-backend
npm install
cp .env.example .env           # edit DATABASE_URL and JWT secrets
npm run migrate                # creates all tables
npm run dev                    # starts server with nodemon hot-reload
```

## Environment Variables

Copy `.env.example` to `.env` and fill in:

| Variable | Required | Description |
|---|---|---|
| `DATABASE_URL` | ✅ | PostgreSQL connection string |
| `JWT_ACCESS_SECRET` | ✅ | Min 32 chars random string |
| `JWT_REFRESH_SECRET` | ✅ | Different random string |
| `SUPABASE_URL` | For file uploads | Your Supabase project URL |
| `SUPABASE_SERVICE_ROLE_KEY` | For file uploads | Service role key (not anon) |
| `AFRICASTALKING_API_KEY` | For SMS OTP | Africa's Talking key |
| `OTP_DEV_MODE` | Dev only | Set `true` to return OTP in response body |
| `RESEND_API_KEY` | For email | Resend API key |

See `.env.example` for the complete list with descriptions.

## Database Migrations

```bash
npm run migrate          # apply all pending migrations (safe to re-run)
```

Migration files live in `src/db/migrations/` and are applied in filename order (001_, 002_, ...). Applied migrations are tracked in the `schema_migrations` table so re-runs skip already-applied files.

## API Reference

Full interactive docs are at `/api-docs` (Swagger UI) when the server is running.

### Auth Endpoints

| Method | Path | Description | Auth |
|---|---|---|---|
| POST | `/api/v1/auth/register/initiate` | Send OTP to phone | Public |
| POST | `/api/v1/auth/register/complete` | Verify OTP + set PIN | Public |
| POST | `/api/v1/auth/login` | Login with phone + PIN | Public |
| POST | `/api/v1/auth/refresh` | Refresh access token | Public |
| POST | `/api/v1/auth/logout` | Revoke refresh token | Bearer |
| POST | `/api/v1/auth/pin-reset/request` | Send reset OTP | Public |
| POST | `/api/v1/auth/pin-reset/confirm` | Set new PIN | Public |
| GET  | `/api/v1/auth/me` | Current user | Bearer |

### Products

| Method | Path | Description | Auth |
|---|---|---|---|
| GET | `/api/v1/products` | List with search + filters | Public |
| GET | `/api/v1/products/:id` | Single product | Public |
| GET | `/api/v1/products/slug/:slug` | By URL slug | Public |
| POST | `/api/v1/products` | Create product | Vendor |
| PUT | `/api/v1/products/:id` | Update product | Vendor/Admin |
| DELETE | `/api/v1/products/:id` | Archive product | Vendor/Admin |
| PATCH | `/api/v1/products/:id/inventory` | Update stock | Vendor/Admin |
| PATCH | `/api/v1/products/:id/status` | Approve/reject | Admin |

### Orders

| Method | Path | Description | Auth |
|---|---|---|---|
| POST | `/api/v1/orders` | Place order | Customer |
| GET | `/api/v1/orders/my` | My order history | Customer |
| GET | `/api/v1/orders/:id` | Order detail | Owner/Admin |
| PATCH | `/api/v1/orders/:id/status` | Update status | Vendor/Rider/Admin |
| POST | `/api/v1/orders/:id/cancel` | Cancel order | Customer/Admin |

### Remaining Modules (stub — return 501)

All other modules (`/users`, `/vendors`, `/riders`, `/admin`, `/payments`, `/delivery`, `/notifications`, `/reviews`, `/messaging`, `/reports`, `/settings`, `/uploads`, `/analytics`) are scaffolded and return a `501 Not Implemented` response with a clear message until their controllers and services are built.

## Project Structure

```
marketlink-backend/
├── src/
│   ├── server.js               # Express app entry point
│   ├── config/
│   │   └── db.js               # PostgreSQL pool + withTransaction helper
│   ├── middleware/
│   │   ├── auth.js             # JWT authentication + role authorization
│   │   ├── validate.js         # express-validator result → 422 response
│   │   └── errorHandler.js     # Centralized error handler + AppError class
│   ├── utils/
│   │   └── logger.js           # Winston structured logger
│   ├── db/
│   │   ├── migrate.js          # Migration runner
│   │   └── migrations/
│   │       ├── 001_core_users.sql
│   │       ├── 002_catalog.sql
│   │       ├── 003_orders_delivery.sql
│   │       ├── 004_payments_wallets.sql
│   │       ├── 005_reviews_messaging.sql
│   │       └── 006_cms_settings_logs.sql
│   ├── docs/
│   │   └── swagger.js          # OpenAPI 3.0 spec (auto-generated)
│   └── modules/
│       ├── auth/               # ✅ Full implementation
│       │   ├── routes.js
│       │   ├── controller.js
│       │   └── service.js
│       ├── products/           # ✅ Full implementation
│       │   ├── routes.js
│       │   ├── controller.js
│       │   └── service.js
│       ├── orders/             # ✅ Full implementation
│       │   ├── routes.js
│       │   ├── controller.js
│       │   └── service.js
│       └── [15 other modules]  # 501 stubs — ready to implement
├── Dockerfile
├── docker-compose.yml
├── .env.example
├── .gitignore
└── package.json
```

## Deployment

### Railway / Render (recommended for Gambia startup budget)

1. Push code to GitHub
2. Create a new Railway/Render project, connect the repo
3. Add environment variables from `.env.example` (all `REQUIRED` ones)
4. Set `DATABASE_URL` to your Supabase or Railway Postgres connection string
5. Set start command: `npm run migrate && npm start`

### Production Checklist

- [ ] Set `OTP_DEV_MODE=false`
- [ ] Use strong random values for all JWT secrets (min 64 chars)
- [ ] Set `DB_SSL=true` for hosted Postgres
- [ ] Set `CORS_ORIGIN` to your exact frontend domain
- [ ] Configure Africa's Talking SMS credentials
- [ ] Configure Resend/SendGrid email credentials
- [ ] Configure Supabase Storage bucket
- [ ] Set up Firebase for push notifications
- [ ] Enable Postgres connection pooling (PgBouncer on Supabase)
- [ ] Set up log aggregation (Logtail, Datadog, or Supabase Logs)

## Security Notes

- PINs are hashed with bcrypt (cost factor 12) — never stored in plaintext
- OTP codes are hashed with bcrypt before storage — never stored in plaintext  
- JWT access tokens expire in 15 minutes; refresh tokens are rotated on use
- Per-device refresh token revocation (logout only affects current device)
- Rate limiting: 10 requests / 15 min on auth endpoints; 300 / 15 min globally
- All inputs validated and sanitised via express-validator before reaching business logic
- Helmet sets security headers on every response
- Audit log records every admin action with before/after state for compliance

## Development Workflow

```bash
npm run dev          # nodemon hot-reload
npm run migrate      # apply pending migrations
npm test             # Jest test suite (add tests to __tests__/ directories)
```

## Adding a New Module

1. Create `src/modules/<name>/service.js` — business logic, calls `db.js`
2. Create `src/modules/<name>/controller.js` — req/res translation
3. Replace the stub in `src/modules/<name>/routes.js` with real routes
4. The module is already mounted in `server.js` at `/api/v1/<name>`

---

Built by Royal FinTech Company · MarketLink Gambia · marketlinkgambia@gmail.com
